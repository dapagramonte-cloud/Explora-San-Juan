import React from "react";
import { NavLink } from "react-router-dom";

const nav = [
  { to: "/", label: "Inicio" },
  { to: "/provincia", label: "Provincia" },
  { to: "/municipios", label: "Municipios" },
  { to: "/turismo", label: "Turismo" },
  { to: "/gastronomia", label: "Gastronomía" },
  { to: "/juegos", label: "Juegos" },
  { to: "/ajustes", label: "Ajustes" }
];

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-10 border-b border-slate-800 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-slate-800 grid place-items-center font-bold">SJ</div>
            <div>
              <div className="text-base font-semibold leading-tight">Explora San Juan</div>
              <div className="text-xs text-slate-400 leading-tight">Aprende y juega</div>
            </div>
          </div>
          <nav className="hidden md:flex gap-1">
            {nav.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  "px-3 py-2 rounded-lg text-sm " +
                  (isActive ? "bg-slate-800 text-white" : "text-slate-300 hover:bg-slate-900")
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>

      <footer className="border-t border-slate-800 py-6">
        <div className="mx-auto max-w-6xl px-4 text-xs text-slate-400">
          Reemplaza los JSON en <span className="text-slate-300">src/data</span> por tu contenido completo.
        </div>
      </footer>

      <div className="md:hidden fixed bottom-0 left-0 right-0 border-t border-slate-800 bg-slate-950/90 backdrop-blur">
        <div className="mx-auto max-w-6xl px-2 py-2 flex gap-1 overflow-x-auto">
          {nav.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                "px-3 py-2 rounded-lg text-sm whitespace-nowrap " +
                (isActive ? "bg-slate-800 text-white" : "text-slate-300 hover:bg-slate-900")
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>
      </div>
      <div className="md:hidden h-14" />
    </div>
  );
}
