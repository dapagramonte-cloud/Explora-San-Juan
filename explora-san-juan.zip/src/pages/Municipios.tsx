import Card from "../components/Card";
import municipios from "../data/municipios.json";
import { Link } from "react-router-dom";

export default function Municipios() {
  return (
    <div className="space-y-4">
      <Card title="Municipios" subtitle={`Total: ${municipios.length}`}>
        <div className="grid gap-3 md:grid-cols-2">
          {municipios.map((m) => (
            <Link key={m.slug} to={`/municipios/${m.slug}`} className="block rounded-2xl border border-slate-800 bg-slate-950/40 p-4 hover:bg-slate-900/50">
              <div className="text-base font-semibold">{m.nombre}</div>
              <div className="text-sm text-slate-300 mt-1">{m.resumen}</div>
              <div className="mt-2 text-xs text-slate-400">Distritos municipales: {m.distritos_municipales.length}</div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
