import { useParams, Link } from "react-router-dom";
import Card from "../components/Card";
import municipios from "../data/municipios.json";

export default function MunicipioDetalle() {
  const { slug } = useParams();
  const m = municipios.find(x => x.slug === slug);

  if (!m) {
    return (
      <Card title="Municipio no encontrado" subtitle="Revisa la URL">
        <Link to="/municipios" className="text-sky-300 hover:underline text-sm">Volver a municipios</Link>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card title={m.nombre} subtitle={m.resumen} right={<Link to="/municipios" className="text-sm text-sky-300 hover:underline">← Volver</Link>}>
        <div className="text-sm font-semibold">Distritos municipales</div>
        <ul className="mt-2 list-disc pl-5 text-sm text-slate-200 space-y-1">
          {m.distritos_municipales.map(d => <li key={d}>{d}</li>)}
        </ul>
      </Card>
    </div>
  );
}
