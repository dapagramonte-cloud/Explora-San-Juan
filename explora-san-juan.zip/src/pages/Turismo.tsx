import { useState } from "react";
import Card from "../components/Card";
import lugares from "../data/lugares.json";

export default function Turismo() {
  const [q, setQ] = useState("");
  const filtered = lugares.filter((l) =>
    (l.nombre + " " + l.descripcion).toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <Card title="Turismo" subtitle="Lugares (demo)">
        <input
          className="w-full rounded-xl border border-slate-800 bg-slate-950/50 px-3 py-2 text-sm"
          placeholder="Buscar..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {filtered.map((l) => (
            <div key={l.id} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
              <div className="text-base font-semibold">{l.nombre}</div>
              <div className="text-xs text-slate-400 mt-1">{l.categoria}</div>
              <p className="text-sm text-slate-200 mt-2">{l.descripcion}</p>
              <div className="mt-2 text-xs text-slate-500">Imagen: {l.imagenes?.[0]?.src ?? "—"}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
