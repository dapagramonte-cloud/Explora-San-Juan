import { useState } from "react";
import Card from "../components/Card";
import { defaultProgress, loadProgress, saveProgress } from "../lib/storage";

export default function Ajustes() {
  const [p, setP] = useState(loadProgress());

  function updateName(name: string) {
    const next = { ...p, name };
    setP(next);
    saveProgress(next);
  }

  function reset() {
    const next = defaultProgress();
    setP(next);
    saveProgress(next);
  }

  return (
    <div className="space-y-4">
      <Card title="Ajustes" subtitle="Progreso">
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-sm font-semibold">Nombre</div>
            <input
              className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/50 px-3 py-2 text-sm"
              value={p.name}
              onChange={(e) => updateName(e.target.value)}
            />
            <div className="mt-3 text-sm text-slate-300">Nivel {p.level} • XP {p.xp}</div>
            <div className="mt-3 flex gap-2">
              <button className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm" onClick={reset}>
                Reiniciar progreso
              </button>
            </div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-sm font-semibold">Insignias</div>
            <ul className="mt-2 list-disc pl-5 text-sm text-slate-200">
              {p.badges.length ? p.badges.map(b => <li key={b}>{b}</li>) : <li>Ninguna aún</li>}
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
