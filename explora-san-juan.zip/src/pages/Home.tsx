import Card from "../components/Card";
import provincia from "../data/provincia.json";
import municipios from "../data/municipios.json";
import { Link } from "react-router-dom";
import { loadProgress } from "../lib/storage";

export default function Home() {
  const progress = loadProgress();
  const dato = provincia.linea_tiempo[Math.floor(Math.random() * provincia.linea_tiempo.length)];

  return (
    <div className="space-y-4">
      <Card title={`Bienvenido/a, ${progress.name}`} subtitle={`Nivel ${progress.level} • XP ${progress.xp}`}>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
            <div className="text-sm text-slate-300 font-medium">Dato del día</div>
            <div className="mt-2 text-sm text-slate-200">
              <span className="font-semibold">{dato.titulo}</span> — {dato.descripcion}
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
            <div className="text-sm text-slate-300 font-medium">Accesos rápidos</div>
            <div className="mt-2 flex flex-wrap gap-2">
              <Link className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm" to="/provincia">Provincia</Link>
              <Link className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm" to="/municipios">Municipios</Link>
              <Link className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm" to="/juegos">Juegos</Link>
            </div>
          </div>
        </div>
      </Card>

      <Card title="Resumen" subtitle={provincia.region}>
        <p className="text-sm text-slate-200">{provincia.resumen}</p>
        <p className="mt-3 text-sm text-slate-400">Municipios: {municipios.length}</p>
      </Card>
    </div>
  );
}
