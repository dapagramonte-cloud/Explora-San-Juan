import { useMemo, useState } from "react";
import Card from "../components/Card";
import quizData from "../data/quiz.json";
import { addXp, loadProgress, saveProgress } from "../lib/storage";

type Question = (typeof quizData)["preguntas"][number];

function shuffle<T>(arr: T[]) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Juegos() {
  const [progress, setProgress] = useState(loadProgress());
  const questions = useMemo(() => shuffle(quizData.preguntas).slice(0, 6), []);
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const current = questions[idx] as Question | undefined;

  function answer(i: number) {
    if (!current || done || selected !== null) return;
    setSelected(i);
    const correct = i === current.respuestaIndex;
    const nextScore = score + (correct ? 1 : 0);
    setScore(nextScore);

    window.setTimeout(() => {
      setSelected(null);
      if (idx + 1 >= questions.length) {
        setDone(true);
        const gained = nextScore * 20;
        const updated = addXp(progress, gained);
        const withBadges = { ...updated, badges: Array.from(new Set([...updated.badges, "Quiz"])) };
        setProgress(withBadges);
        saveProgress(withBadges);
      } else {
        setIdx(idx + 1);
      }
    }, 600);
  }

  return (
    <div className="space-y-4">
      <Card title="Juegos" subtitle={`Nivel ${progress.level} • XP ${progress.xp} • Puntos: ${score}`}>
        {current ? (
          <>
            <div className="text-sm text-slate-400">Pregunta {idx + 1} / {questions.length}</div>
            <div className="mt-2 text-base font-semibold">{current.pregunta}</div>
            <div className="mt-3 grid gap-2">
              {current.opciones.map((op, i) => {
                const isCorrect = selected !== null && i === current.respuestaIndex;
                const isWrong = selected === i && selected !== current.respuestaIndex;
                const cls =
                  "text-left rounded-xl border px-3 py-3 text-sm transition " +
                  (selected === null
                    ? "border-slate-700 bg-slate-950/40 hover:bg-slate-900/60"
                    : isCorrect
                    ? "border-emerald-700 bg-emerald-950/40"
                    : isWrong
                    ? "border-rose-700 bg-rose-950/40"
                    : "border-slate-800 bg-slate-950/30");

                return (
                  <button key={i} className={cls} onClick={() => answer(i)} disabled={selected !== null || done}>
                    {op}
                  </button>
                );
              })}
            </div>
            {done ? <p className="mt-3 text-sm text-slate-300">Completado. Ganaste XP por tu puntuación.</p> : null}
          </>
        ) : (
          <p className="text-sm text-slate-300">Cargando...</p>
        )}
      </Card>
    </div>
  );
}
