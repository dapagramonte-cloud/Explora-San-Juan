import Card from "../components/Card";
import provincia from "../data/provincia.json";

export default function Provincia() {
  return (
    <div className="space-y-4">
      <Card title={provincia.nombre} subtitle={`${provincia.pais} • ${provincia.region}`}>
        <p className="text-sm text-slate-200">{provincia.resumen}</p>
      </Card>

      <Card title="Línea de tiempo" subtitle="Hechos (resumen)">
        <ol className="space-y-3">
          {provincia.linea_tiempo.map((h) => (
            <li key={h.fecha} className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
              <div className="text-xs text-slate-400">{h.fecha}</div>
              <div className="text-sm font-semibold">{h.titulo}</div>
              <div className="text-sm text-slate-200 mt-1">{h.descripcion}</div>
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}
