import { useState } from "react";
import Card from "../components/Card";
import gastronomia from "../data/gastronomia.json";

export default function Gastronomia() {
  const [q, setQ] = useState("");
  const filtered = gastronomia.filter((r) =>
    (r.nombre + " " + r.descripcion).toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <Card title="Gastronomía" subtitle="Recetas (demo)">
        <input
          className="w-full rounded-xl border border-slate-800 bg-slate-950/50 px-3 py-2 text-sm"
          placeholder="Buscar receta..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {filtered.map((r) => (
            <div key={r.id} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
              <div className="text-base font-semibold">{r.nombre}</div>
              <div className="text-xs text-slate-400 mt-1">{r.tipo}</div>
              <p className="text-sm text-slate-200 mt-2">{r.descripcion}</p>
              <div className="mt-3 text-sm font-semibold">Ingredientes</div>
              <ul className="mt-1 list-disc pl-5 text-sm text-slate-200">
                {r.ingredientes.slice(0, 6).map((i) => <li key={i}>{i}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
