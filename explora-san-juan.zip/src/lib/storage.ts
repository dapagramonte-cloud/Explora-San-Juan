export type Progress = {
  name: string;
  xp: number;
  level: number;
  badges: string[];
};

const KEY = "explora_san_juan_progress_v1";

export function defaultProgress(): Progress {
  return { name: "Explorador/a", xp: 0, level: 1, badges: [] };
}

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultProgress();
    return { ...defaultProgress(), ...(JSON.parse(raw) as Progress) };
  } catch {
    return defaultProgress();
  }
}

export function saveProgress(p: Progress) {
  localStorage.setItem(KEY, JSON.stringify(p));
}

export function addXp(p: Progress, amount: number): Progress {
  const threshold = (lvl: number) => 100 + (lvl - 1) * 75;
  let xpTotal = p.xp + Math.max(0, amount);
  let level = p.level;
  let xp = xpTotal;
  while (xp >= threshold(level)) {
    xp -= threshold(level);
    level += 1;
  }
  return { ...p, xp, level };
}
