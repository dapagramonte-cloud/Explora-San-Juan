import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Provincia from "./pages/Provincia";
import Municipios from "./pages/Municipios";
import MunicipioDetalle from "./pages/MunicipioDetalle";
import Turismo from "./pages/Turismo";
import Gastronomia from "./pages/Gastronomia";
import Juegos from "./pages/Juegos";
import Ajustes from "./pages/Ajustes";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/provincia" element={<Provincia />} />
        <Route path="/municipios" element={<Municipios />} />
        <Route path="/municipios/:slug" element={<MunicipioDetalle />} />
        <Route path="/turismo" element={<Turismo />} />
        <Route path="/gastronomia" element={<Gastronomia />} />
        <Route path="/juegos" element={<Juegos />} />
        <Route path="/ajustes" element={<Ajustes />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}
