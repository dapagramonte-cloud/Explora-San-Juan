# Explora San Juan

App educativa (React + Vite + TypeScript + Tailwind + React Router) con secciones y juegos.

## Ejecutar
```bash
npm install
npm run dev
```

## Build / Preview
```bash
npm run build
npm run preview
```

## Deploy en Vercel
Ver `DEPLOY.md`. Incluye `vercel.json` para evitar 404 al refrescar rutas.
