# Publicar “Explora San Juan” en Vercel (por clicks)

## 1) Probar localmente
```bash
npm install
npm run dev
```

Producción:
```bash
npm run build
npm run preview
```

## 2) Subir a GitHub
Crea un repo y sube todo el proyecto (incluye `vercel.json`).

## 3) Desplegar en Vercel
Vercel → Add New… → Project → Import repo → Deploy  
Settings:
- Build Command: `npm run build`
- Output Directory: `dist`

## 4) Probar rutas
Abre `/municipios/san-juan-de-la-maguana` y presiona F5 (no debe dar 404).

## Nota PWA
Reemplaza `public/pwa-192.png` y `public/pwa-512.png` por PNG reales (192 y 512).
